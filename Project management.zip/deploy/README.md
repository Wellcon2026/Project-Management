# Wellcon PM

ระบบบริหารโครงการ (Project Management) ของบริษัท เวลล์คอน อินทีเรีย จำกัด

## Files
- `Wellcon PM.dc.html` — แอปหลัก (Overview, Finance, BOQ, VO/SI/EOT, Drawing LOG, RFI/RFA, Material LOG, Staff, Store, Procurement, Admin)
- `support.js` — runtime
- `boq-mvc.js` — BOQ โครงการ MVC (274 รายการ)
- `materials-data.js` — ฐานข้อมูลวัสดุ (196 รายการ, 9 หมวด)
- `staff-data.js` — ข้อมูลพนักงาน
- `index.html` — redirect ไปยังแอปหลัก

## Deploy
Static site — ไม่ต้อง build. ชี้ Vercel/Netlify ไปที่ root ของ repo ได้เลย

## Push
```bash
git init
git add .
git commit -m "Wellcon PM"
git remote add origin https://github.com/Wellcon2026/Project-Management.git
git branch -M main
git push -u origin main
```
