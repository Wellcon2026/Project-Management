repo: Wellcon2026/Project-Management
branch: main

## Last sync
date: 2026-07-28T00:00:00Z
note: repo empty at time of check (409 on tree). Code pushed manually by user from deploy/ package — no commit sha known.

### Updated in this project
- Wellcon PM app packaged for push (5 files + index.html redirect)

## Screen map
| Screen | Built from |
| --- | --- |
| Wellcon PM (all tabs) | Wellcon PM.dc.html |
| BOQ MVC data | boq-mvc.js |
| Materials | materials-data.js |
| Staff | staff-data.js |
