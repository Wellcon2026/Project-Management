# Stock Wellcon — project notes

## Persistent rules
- **ทุกช่องค้นหา (search) ในแอปต้องไฮไลต์ตัวอักษรที่ match เสมอ** — ใช้พื้นหลังสีทองอ่อน (`background:#F3E4C0;color:#6E5424`) ครอบส่วนที่ตรงกับคำค้น (ทั้งชื่อสินค้า, SKU, ฯลฯ). ทำผ่าน helper ที่คืน React fragment แล้ว expose เป็น `*El` (เช่น `nameEl`, `skuEl`) ไม่ใช่ string ธรรมดา.
- **แถวปุ่มเลือก (chips) ที่มีจำนวนมากจนเลยขอบจอ ให้เปลี่ยนเป็น dropdown (`<select>`) แทน** — เช่น เลือกคลัง/โครงการ/หมวด. อย่าใช้แถว chip เลื่อนแนวนอนที่ล้นจอ.

## Main app
- `Wellcon Inventory.dc.html` — แอปหลัก (ระบบเบิกของ & คลังพัสดุ)
- `materials-data.js` — ฐานข้อมูลวัสดุจริง (196 รายการ, 9 หมวด A–I), คลัง, โครงการ, movements, requests. โหลดผ่าน `window.WELLCON_MATERIALS`.
- โครงการ: MVC, LPG, TRV, บ้านคุณพงษ์ศักดิ์, บ้านคุณบรม, canopy (p1–p6)
- คลังกลาง: Store ชั้น 1, Store ชั้น 3, โกดัง /20 · คลังไซต์แยกตามโครงการ
